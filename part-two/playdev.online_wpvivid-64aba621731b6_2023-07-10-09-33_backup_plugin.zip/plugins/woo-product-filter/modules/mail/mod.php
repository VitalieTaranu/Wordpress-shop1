<?php
class MailWpf extends ModuleWpf {
		
	public function init() {
		parent::init();
	}
	
}
